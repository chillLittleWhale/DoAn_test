package model;

import java.util.ArrayList;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import org.jdesktop.animation.timing.Animator;

public class Account {
    private String sdt;    // primary key
    private String mk;
    private String email;
    private String role;   // admin hay sv
    private String name;
    private Date ngaySinh;
    private boolean gioiTinh;  // nam 1, nu 0
    private String queQuan;
    private String nganh;
    private String truong;
    private ArrayList< String> dsHocKy;
    private float diemTichLuy;
    private final Animator animator = null;
    public Account() { 
        this.role = "sv";
        this.name = "";
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        try {
            this.ngaySinh = (Date) dateFormat.parse("01-01-2000");
        } catch (ParseException e) {
            e.printStackTrace();
        }
        this.gioiTinh = true;
        this.queQuan ="";
        this.nganh = "";
        this.truong= "";
        this.dsHocKy = new ArrayList<>();
        this.diemTichLuy = 0;
    }
    public Account(String sdt, String mk, String email) {
        this.sdt = sdt;
        this.mk = mk;
        this.email = email;
        this.role = "sv";
        this.name = "";
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        try {
            this.ngaySinh = (Date) dateFormat.parse("01-01-2000");
        } catch (ParseException e) {
            e.printStackTrace();
        }
        this.gioiTinh = true;
        this.queQuan ="";
        this.nganh = "";
        this.truong= "";
        this.dsHocKy = new ArrayList<>();
        this.diemTichLuy = 0;
    }
    

    public String getDsHKString() {
        // tạo chuỗi, phân cách các phần tử bằng dấu phẩy ",", để cho vào sql
        return String.join(",", dsHocKy); 
    }
    public void setDsHKFromString(String dsBanStr) {
        // cho vào 1 chuỗi từ trong sql, đặt cho ds học kỳ của account
        dsHocKy = new ArrayList<String>(Arrays.asList(dsBanStr.split(",")));
    }

    public ArrayList<String> getDsHocKy() {
        return dsHocKy;
    }

    public void setDsHocKy(ArrayList<String> dsHocKy) {
        this.dsHocKy = dsHocKy;
    }

    public String getSdt() {
        return sdt;
    }
    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getMk() {
        return mk;
    }
    public void setMk(String mk) {
        this.mk = mk;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(Date ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public boolean isGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(boolean gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getQueQuan() {
        return queQuan;
    }

    public void setQueQuan(String queQuan) {
        this.queQuan = queQuan;
    }

    public String getNganh() {
        return nganh;
    }

    public void setNganh(String nganh) {
        this.nganh = nganh;
    }

    public String getTruong() {
        return truong;
    }

    public void setTruong(String truong) {
        this.truong = truong;
    }

    public float getDiemTichLuy() {
        return diemTichLuy;
    }

    public void setDiemTichLuy(float diemTichLuy) {
        this.diemTichLuy = diemTichLuy;
    }
    
    
}
