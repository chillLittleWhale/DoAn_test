package controller;
import java.sql.*;
import java.util.*;
import model.Account;

public class DAO_sv {
    private Connection conn;
    
    public DAO_sv(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;"
                    + "databasename=QL_DiemThi;username=tam;password=12345;encrypt=false");
        } catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public boolean addAccount( Account acc){
        String sql = "INSERT INTO tbl_Account(SDT, MATKHAU, EMAIL, VAITRO, HOTEN, NGAYSINH, GIOITINH, QUEQUAN, NGANH, TRUONG, DSHOCKY, DIEMTICHLUY) "
                + "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, acc.getSdt());
            ps.setString(2, acc.getMk());
            ps.setString(3, acc.getEmail());
            ps.setString(4, acc.getRole());
            ps.setDate(5, acc.getNgaySinh());
            ps.setString(6, acc.getRole());
            ps.setString(7, acc.getRole());
            ps.setString(8, acc.getRole());
            ps.setString(9, acc.getRole());
            ps.setString(10, acc.getRole());
            ps.setString(11, acc.getRole());
            ps.setString(12, acc.getRole());
            
            return ps.executeUpdate()>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public ArrayList< Account> getAccList(){
        ArrayList< Account> accList = new ArrayList<>();
        String sql = "SELECT * FROM tbl_Account";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Account acc = new Account(rs.getString("SDT"),
                        rs.getString("MATKHAU"),
                        rs.getString("EMAIL"));
                acc.setRole(rs.getString("VAITRO"));
                accList.add(acc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return accList;
    }
    
    public ArrayList<String> setDsHKFromString(String dsBanStr) {
        // cho vào 1 chuỗi từ trong sql, đặt cho ds học kỳ của account
        return new ArrayList<String>(Arrays.asList(dsBanStr.split(",")));
    }
    
    // lấy đầy đủ 1 tất cả thông tin của 1 user duy nhất
    public Account getAccBySdt(String sdt){
        Account acc = new Account();
        String sql = "SELECT * FROM tbl_Account WHERE SDT = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, sdt);
            ResultSet rs = ps.executeQuery();
//            acc = new Account(rs.getString("SDT"),
//                    rs.getString("MATKHAU"),
//                    rs.getString("EMAIL"));
//            
//            acc.setRole(rs.getString("VAITRO"));
//            acc.setName(rs.getString("HOTEN"));
//            acc.setNgaySinh(rs.getDate("NGAYSINH"));
//            acc.setGioiTinh(rs.getBoolean("GIOITINH"));
//            acc.setQueQuan(rs.getString("QUEQUAN"));
//            acc.setNganh(rs.getString("NGANH"));
//            acc.setTruong(rs.getString("TRUONG"));
//            acc.setDsHocKy(setDsHKFromString(rs.getString("NGANH")));
//            acc.setDiemTichLuy(rs.getFloat("DIEMTICHLUY"));
            if (rs.next()) {
            acc = new Account(rs.getString("SDT"),
                    rs.getString("MATKHAU"),
                    rs.getString("EMAIL"));
            
            acc.setRole(rs.getString("VAITRO"));
            acc.setName(rs.getString("HOTEN"));
            acc.setNgaySinh(rs.getDate("NGAYSINH"));
            acc.setGioiTinh(rs.getBoolean("GIOITINH"));
            acc.setQueQuan(rs.getString("QUEQUAN"));
            acc.setNganh(rs.getString("NGANH"));
            acc.setTruong(rs.getString("TRUONG"));
            acc.setDsHocKy(setDsHKFromString(rs.getString("NGANH")));
            acc.setDiemTichLuy(rs.getFloat("DIEMTICHLUY"));
        }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return acc;
    }
    
    public static void main(String[] args) {
        new DAO_sv();
    }
}