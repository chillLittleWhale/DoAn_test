
package view;

import javax.swing.*;
import controller.DAO_sv;
import java.util.ArrayList;
import model.Account;
public class sign_up extends javax.swing.JFrame {

    public sign_up() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label_email = new javax.swing.JLabel();
        txt_email = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        label_sdt = new javax.swing.JLabel();
        label_passWord = new javax.swing.JLabel();
        txt_sdt = new javax.swing.JTextField();
        txt_mk = new javax.swing.JPasswordField();
        label_xacNhanmk = new javax.swing.JLabel();
        txt_xacNhanmk = new javax.swing.JPasswordField();
        checkBox_dieuKhoan = new javax.swing.JCheckBox();
        btn_dangKi = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        label_dangNhap = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Trang đăng kí");
        setAlwaysOnTop(true);
        setResizable(false);

        label_email.setText("Email :");

        txt_email.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_emailFocusLost(evt);
            }
        });
        txt_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_emailActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel4.setText("Sign up");

        label_sdt.setText("Số điện thoại :");

        label_passWord.setText("Mật khẩu :");

        txt_sdt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        txt_sdt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_sdtFocusLost(evt);
            }
        });
        txt_sdt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_sdtActionPerformed(evt);
            }
        });

        txt_mk.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_mkFocusLost(evt);
            }
        });
        txt_mk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_mkActionPerformed(evt);
            }
        });

        label_xacNhanmk.setText("Xác nhận mật khẩu :");

        checkBox_dieuKhoan.setText("I accept the Terms of Use & Privacy Policy.");
        checkBox_dieuKhoan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkBox_dieuKhoanActionPerformed(evt);
            }
        });

        btn_dangKi.setText("Đăng kí");
        btn_dangKi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_dangKiMouseClicked(evt);
            }
        });
        btn_dangKi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_dangKiActionPerformed(evt);
            }
        });
        btn_dangKi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btn_dangKiKeyPressed(evt);
            }
        });

        jLabel1.setText("Đã có tài khoản ?");

        label_dangNhap.setForeground(new java.awt.Color(0, 102, 255));
        label_dangNhap.setText("Đăng nhập");
        label_dangNhap.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        label_dangNhap.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_dangNhapMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(162, 162, 162))
            .addGroup(layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(checkBox_dieuKhoan, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(label_passWord, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(label_email, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                                .addComponent(label_xacNhanmk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(label_sdt, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txt_email, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_mk, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
                            .addComponent(txt_xacNhanmk, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_sdt))))
                .addGap(0, 89, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(187, 187, 187)
                        .addComponent(btn_dangKi, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(141, 141, 141)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_dangNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_sdt)
                    .addComponent(txt_sdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_passWord)
                    .addComponent(txt_mk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_xacNhanmk)
                    .addComponent(txt_xacNhanmk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_email)
                    .addComponent(txt_email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(checkBox_dieuKhoan)
                .addGap(18, 18, 18)
                .addComponent(btn_dangKi)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(label_dangNhap))
                .addGap(26, 26, 26))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_sdtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_sdtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_sdtActionPerformed

    private void txt_mkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_mkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_mkActionPerformed

    private void txt_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailActionPerformed

    private void btn_dangKiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_dangKiActionPerformed
        
        if(this.isVisible()){
            boolean ok = true;
            String mk = new String(txt_mk.getPassword());
            String xnmk = new String(txt_xacNhanmk.getPassword());
            if(txt_sdt.getText().equals("")){
                ok = false;
                JOptionPane.showMessageDialog(rootPane, " số điện thoại không được để trống");
                return;
            }
            else if(txt_sdt.getText().length() != 10){
                ok = false;
                JOptionPane.showMessageDialog(rootPane, " số điện thoại không đúng định dạng");
                return;
            }
            else if(mk.equals("")){
                ok = false;
                JOptionPane.showMessageDialog(rootPane, " mật khẩu không được để trống");
                return;
            }
            else if(xnmk.equals("")){
                ok = false;
                JOptionPane.showMessageDialog(rootPane, " xác nhận mật khẩu không được để trống");
                return;
            }
            else if(!mk.equals(xnmk)){
                ok = false;
                JOptionPane.showMessageDialog(rootPane, "mật khẩu không trùng khớp");
                return;
            }
            else if(txt_email.getText().equals("")){
                ok = false;
                JOptionPane.showMessageDialog(rootPane, "email không được để trống");
                return;
            }
            else if(!txt_email.getText().matches("\\w+@gmail\\.com")){
                ok = false;
                JOptionPane.showMessageDialog(this, "Email không hợp lệ!");
                return;
            }
            else if(!checkBox_dieuKhoan.isSelected()){
                ok = false;
                JOptionPane.showMessageDialog(rootPane, " bạn chưa đồng ý các điều khoản");
                return;
            }
            else{
                Account acc = new Account(txt_sdt.getText(),mk, txt_email.getText());
                if( new DAO_sv().addAccount(acc)){
                    JOptionPane.showMessageDialog(rootPane, "Đăng ký thành công");
                } else {
                    JOptionPane.showMessageDialog(rootPane, "sdt không được trùng");
                }
            }
            
        }
    }//GEN-LAST:event_btn_dangKiActionPerformed

    private void checkBox_dieuKhoanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkBox_dieuKhoanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkBox_dieuKhoanActionPerformed

    private void label_dangNhapMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_dangNhapMouseClicked
        log_in liform = new log_in();
        liform.setVisible(true);
        liform.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_label_dangNhapMouseClicked

    private void btn_dangKiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_dangKiMouseClicked
        
    }//GEN-LAST:event_btn_dangKiMouseClicked

    private void txt_emailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_emailFocusLost
        
    }//GEN-LAST:event_txt_emailFocusLost

    private void txt_sdtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_sdtFocusLost
        
    }//GEN-LAST:event_txt_sdtFocusLost

    private void txt_mkFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_mkFocusLost
        if(this.isVisible()){
            String password = new String(txt_mk.getPassword());
            if (password.length() < 5) {
                JOptionPane.showMessageDialog(this, 
                        "Mật khẩu phải có ít nhất 5 ký tự");
                return;
            }
            if (!password.matches("^(?=.*[0-9])(?=.*[a-zA-Z])(?=\\S+$).{5,}$")) {
                JOptionPane.showMessageDialog(this,
                        "Mật khẩu cần bao gồm cả ký tự và số, không chứa dấu cách");
                return;
            }
        }
    }//GEN-LAST:event_txt_mkFocusLost

    private void btn_dangKiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btn_dangKiKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_dangKiKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(sign_up.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(sign_up.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(sign_up.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(sign_up.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new sign_up().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_dangKi;
    private javax.swing.JCheckBox checkBox_dieuKhoan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel label_dangNhap;
    private javax.swing.JLabel label_email;
    private javax.swing.JLabel label_passWord;
    private javax.swing.JLabel label_sdt;
    private javax.swing.JLabel label_xacNhanmk;
    private javax.swing.JTextField txt_email;
    private javax.swing.JPasswordField txt_mk;
    private javax.swing.JTextField txt_sdt;
    private javax.swing.JPasswordField txt_xacNhanmk;
    // End of variables declaration//GEN-END:variables
}
